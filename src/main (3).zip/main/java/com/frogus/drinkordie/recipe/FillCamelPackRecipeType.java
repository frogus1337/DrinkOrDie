package com.frogus.drinkordie.recipe;

import net.minecraft.world.item.crafting.RecipeType;

public class FillCamelPackRecipeType implements RecipeType<FillCamelPackRecipe> {
    public static final FillCamelPackRecipeType INSTANCE = new FillCamelPackRecipeType();

    @Override
    public String toString() {
        return "drinkordie:camel_pack_fill";
    }
}

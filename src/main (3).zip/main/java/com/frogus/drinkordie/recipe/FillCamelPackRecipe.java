package com.frogus.drinkordie.recipe;

import com.frogus.drinkordie.item.CamelPackItem;
import com.frogus.drinkordie.item.ModItems;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.level.Level;

public class FillCamelPackRecipe implements CraftingRecipe {

    private final ResourceLocation id;

    public FillCamelPackRecipe(ResourceLocation id) {
        this.id = id;
    }

    @Override
    public boolean matches(Container inv, Level world) {
        int packs = 0, bottles = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) continue;
            if (s.getItem() == ModItems.CAMEL_PACK.get()) packs++;
            else if (s.getItem() == Items.POTION && s.hasTag() && "minecraft:water".equals(s.getTag().getString("Potion"))) bottles++;
            else return false;
        }
        return packs == 1 && bottles > 0;
    }

    @Override
    public ItemStack assemble(Container inv, RegistryAccess access) {
        ItemStack pack = ItemStack.EMPTY;
        int bottles = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) continue;
            if (s.getItem() == ModItems.CAMEL_PACK.get() && pack.isEmpty()) pack = s.copy();
            else if (s.getItem() == Items.POTION && s.hasTag() && "minecraft:water".equals(s.getTag().getString("Potion"))) bottles++;
        }
        if (pack.isEmpty() || bottles == 0) return ItemStack.EMPTY;
        int prevMb = CamelPackItem.getWater(pack);
        int toFill = Math.min(bottles * 1000, CamelPackItem.CAPACITY - prevMb);
        int newMb = prevMb + toFill;
        CamelPackItem.setWater(pack, newMb);
        pack.setCount(1);
        return pack;
    }

    @Override
    public boolean canCraftInDimensions(int w, int h) {
        return w * h >= 2;
    }

    @Override
    public ItemStack getResultItem(RegistryAccess access) {
        ItemStack preview = new ItemStack(ModItems.CAMEL_PACK.get());
        CamelPackItem.setWater(preview, CamelPackItem.CAPACITY);
        return preview;
    }

    @Override
    public ResourceLocation getId() {
        return id;
    }

    @Override
    public RecipeType<?> getType() {
        return RecipeType.CRAFTING;
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        NonNullList<Ingredient> list = NonNullList.create();
        list.add(Ingredient.of(ModItems.CAMEL_PACK.get()));
        list.add(Ingredient.of(new ItemStack(Items.POTION))); // Option: spezifischer mit NBT, wenn Forge das unterstützt
        return list;
    }

    @Override
    public boolean isSpecial() {
        return true; // Optional: false, wenn es im Rezeptbuch angezeigt werden soll
    }
}

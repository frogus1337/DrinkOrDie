package com.frogus.drinkordie.recipe;

import com.google.gson.JsonObject;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraftforge.common.crafting.CraftingHelper;

public class FillCamelPackRecipeSerializer implements RecipeSerializer<FillCamelPackRecipe> {
    @Override
    public FillCamelPackRecipe fromJson(ResourceLocation id, JsonObject json) {
        Ingredient camelPack = Ingredient.fromJson(json.get("camel_pack"));
        Ingredient waterBottle = Ingredient.fromJson(json.get("water_bottle"));
        ItemStack result = CraftingHelper.getItemStack(json.getAsJsonObject("result"), true);
        return new FillCamelPackRecipe(id, camelPack, waterBottle, result);
    }

    @Override
    public FillCamelPackRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buf) {
        Ingredient camelPack = Ingredient.fromNetwork(buf);
        Ingredient waterBottle = Ingredient.fromNetwork(buf);
        ItemStack result = buf.readItem();
        return new FillCamelPackRecipe(id, camelPack, waterBottle, result);
    }

    @Override
    public void toNetwork(FriendlyByteBuf buf, FillCamelPackRecipe recipe) {
        recipe.camelPack.toNetwork(buf);
        recipe.waterBottle.toNetwork(buf);
        buf.writeItem(recipe.result);
    }
}

package com.frogus.drinkordie.recipe;

import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.eventbus.api.IEventBus;

public class ModRecipes {
    public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS =
            DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, "drinkordie");
    public static final DeferredRegister<RecipeType<?>> TYPES =
            DeferredRegister.create(ForgeRegistries.RECIPE_TYPES, "drinkordie");

    public static final RegistryObject<RecipeSerializer<FillCamelPackRecipe>> FILL_CAMEL_PACK_SERIALIZER =
            SERIALIZERS.register("camel_pack_fill", FillCamelPackRecipeSerializer::new);

    public static final RegistryObject<RecipeType<FillCamelPackRecipe>> FILL_CAMEL_PACK_TYPE =
            TYPES.register("camel_pack_fill", () -> FillCamelPackRecipeType.INSTANCE);

    public static void register(IEventBus eventBus) {
        SERIALIZERS.register(eventBus);
        TYPES.register(eventBus);
        System.out.println("[DrinkOrDie] Custom RecipeType & Serializer registered!");
    }
}

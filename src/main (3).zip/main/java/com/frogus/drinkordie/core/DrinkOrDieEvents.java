package com.frogus.drinkordie.core;

import com.frogus.drinkordie.recipe.ModRecipes;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class DrinkOrDieEvents {
    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        MinecraftServer server = event.getServer();
        var recipeManager = server.getRecipeManager();

        var camelPackType = ModRecipes.FILL_CAMEL_PACK_TYPE.get();
        var recipes = recipeManager.getAllRecipesFor(camelPackType);

        System.out.println("[DrinkOrDie] ---- Registrierte FillCamelPack-Rezepte ----");
        for (var recipe : recipes) {
            System.out.println("ID: " + recipe.getId());
            // Optional: Hier noch weitere Infos, z.B. Ausgabe oder Zutaten:
            System.out.println("   Result: " + recipe.getResultItem(server.registryAccess()));
        }
        if (recipes.isEmpty()) {
            System.out.println("[DrinkOrDie] KEINE FillCamelPack-Rezepte gefunden!");
        }
    }
}

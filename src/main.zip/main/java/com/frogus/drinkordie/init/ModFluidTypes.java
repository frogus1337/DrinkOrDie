package com.frogus.drinkordie.init;

import net.minecraftforge.fluids.FluidType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.frogus.drinkordie.core.DrinkOrDie;

public class ModFluidTypes {
    public static final DeferredRegister<FluidType> FLUID_TYPES =
            DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, DrinkOrDie.MODID);

    public static final RegistryObject<FluidType> DIRTY_WATER_TYPE = FLUID_TYPES.register("dirty_water",
            () -> new FluidType(FluidType.Properties.create().density(1000).viscosity(1000).lightLevel(0)){});

    public static final RegistryObject<FluidType> SALTY_WATER_TYPE = FLUID_TYPES.register("salty_water",
            () -> new FluidType(FluidType.Properties.create().density(1000).viscosity(1000).lightLevel(0)){});

    public static void register() {
        FLUID_TYPES.register(net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus());
    }
}

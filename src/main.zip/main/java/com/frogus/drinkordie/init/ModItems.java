package com.frogus.drinkordie.init;

import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.frogus.drinkordie.core.DrinkOrDie;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, DrinkOrDie.MODID);

    // Normale Items
    public static final RegistryObject<Item> DIRTY_WATER_BOTTLE = ITEMS.register("dirty_water_bottle",
            () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SALTY_WATER_BOTTLE = ITEMS.register("salty_water_bottle",
            () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> CANTEEN = ITEMS.register("canteen",
            () -> new Item(new Item.Properties().stacksTo(1).durability(10)));
    public static final RegistryObject<Item> CAMEL_PACK = ITEMS.register("camel_pack",
            () -> new Item(new Item.Properties().stacksTo(1).durability(40)));
    public static final RegistryObject<Item> SALT = ITEMS.register("salt",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BOTTLE_OF_SALT = ITEMS.register("bottle_of_salt",
            () -> new Item(new Item.Properties().stacksTo(1)));

    // Fluid-Buckets (Eimer)
    public static final RegistryObject<Item> DIRTY_WATER_BUCKET = ITEMS.register("dirty_water_bucket",
            () -> new BucketItem(ModFluids.DIRTY_WATER,
                    new Item.Properties()
                            .craftRemainder(net.minecraft.world.item.Items.BUCKET)
                            .stacksTo(1)
            )
    );
    public static final RegistryObject<Item> SALTY_WATER_BUCKET = ITEMS.register("salty_water_bucket",
            () -> new BucketItem(ModFluids.SALTY_WATER,
                    new Item.Properties()
                            .craftRemainder(net.minecraft.world.item.Items.BUCKET)
                            .stacksTo(1)
            )
    );

    public static void register() {
        ITEMS.register(net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus());
    }
}

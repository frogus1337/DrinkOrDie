package com.frogus.drinkordie.init;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.frogus.drinkordie.core.DrinkOrDie;

public class ModFluids {
    public static final DeferredRegister<Fluid> FLUIDS =
            DeferredRegister.create(ForgeRegistries.FLUIDS, DrinkOrDie.MODID);

    // Dirty Water
    public static final RegistryObject<FlowingFluid> DIRTY_WATER = FLUIDS.register("dirty_water",
            () -> new ForgeFlowingFluid.Source(DIRTY_WATER_PROPERTIES()));
    public static final RegistryObject<FlowingFluid> DIRTY_WATER_FLOWING = FLUIDS.register("dirty_water_flowing",
            () -> new ForgeFlowingFluid.Flowing(DIRTY_WATER_PROPERTIES()));

    // Salty Water
    public static final RegistryObject<FlowingFluid> SALTY_WATER = FLUIDS.register("salty_water",
            () -> new ForgeFlowingFluid.Source(SALTY_WATER_PROPERTIES()));
    public static final RegistryObject<FlowingFluid> SALTY_WATER_FLOWING = FLUIDS.register("salty_water_flowing",
            () -> new ForgeFlowingFluid.Flowing(SALTY_WATER_PROPERTIES()));

    private static ForgeFlowingFluid.Properties DIRTY_WATER_PROPERTIES() {
        return new ForgeFlowingFluid.Properties(
                ModFluidTypes.DIRTY_WATER_TYPE,
                DIRTY_WATER,
                DIRTY_WATER_FLOWING
        )
                .bucket(ModItems.DIRTY_WATER_BUCKET)
                .block(ModBlocks.DIRTY_WATER_BLOCK);
    }

    private static ForgeFlowingFluid.Properties SALTY_WATER_PROPERTIES() {
        return new ForgeFlowingFluid.Properties(
                ModFluidTypes.SALTY_WATER_TYPE,
                SALTY_WATER,
                SALTY_WATER_FLOWING
        )
                .bucket(ModItems.SALTY_WATER_BUCKET)
                .block(ModBlocks.SALTY_WATER_BLOCK);
    }

    public static void register() {
        FLUIDS.register(net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus());
    }
}

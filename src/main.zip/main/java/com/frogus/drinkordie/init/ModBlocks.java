package com.frogus.drinkordie.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.frogus.drinkordie.core.DrinkOrDie;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, DrinkOrDie.MODID);

    // RICHTIG: Übergib einen Supplier für das Fluid, NICHT das RegistryObject direkt!
    public static final RegistryObject<LiquidBlock> DIRTY_WATER_BLOCK = BLOCKS.register("dirty_water",
            () -> new LiquidBlock(
                    () -> ModFluids.DIRTY_WATER.get(),
                    Block.Properties.of().noCollission().strength(100.0F).noLootTable()));

    public static final RegistryObject<LiquidBlock> SALTY_WATER_BLOCK = BLOCKS.register("salty_water",
            () -> new LiquidBlock(
                    () -> ModFluids.SALTY_WATER.get(),
                    Block.Properties.of().noCollission().strength(100.0F).noLootTable()));

    public static void register() {
        BLOCKS.register(net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus());
    }
}

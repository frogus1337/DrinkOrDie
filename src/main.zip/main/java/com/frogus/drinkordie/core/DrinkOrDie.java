package com.frogus.drinkordie.core;

import com.frogus.drinkordie.data.BalanceHydrationConfig;
import com.frogus.drinkordie.data.BalanceTemperatureConfig;
import com.frogus.drinkordie.data.DataMap;
import com.frogus.drinkordie.network.DrinkOrDieNetwork;
import com.frogus.drinkordie.temperature.TemperatureCommand;
import com.frogus.drinkordie.init.ModItems;
import com.frogus.drinkordie.init.ModFluids;
import com.frogus.drinkordie.init.ModFluidTypes;
import com.frogus.drinkordie.init.ModBlocks;
import com.frogus.drinkordie.core.DrinkOrDieGeneralCommands;
import com.mojang.logging.LogUtils;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;


@Mod(DrinkOrDie.MODID)
public class DrinkOrDie {
    public static final String MODID = "drinkordie";
    private static final Logger LOGGER = LogUtils.getLogger();

    public DrinkOrDie() {
        // 1. FluidTypes zuerst registrieren!
        ModFluidTypes.register();

        // 2. Fluids, Blocks, Items
        ModFluids.register();
        ModBlocks.register();
        ModItems.register();

        // 3. Netzwerk
        DrinkOrDieNetwork.register();

        // *** Die setupProperties-Zeile ist WEG! ***

        // 4. Konfigs laden
        DataMap.loadJsonConfig(net.minecraftforge.fml.loading.FMLPaths.CONFIGDIR.get());
        BalanceHydrationConfig.loadJsonConfig(net.minecraftforge.fml.loading.FMLPaths.CONFIGDIR.get());
        BalanceTemperatureConfig.loadJsonConfig(net.minecraftforge.fml.loading.FMLPaths.CONFIGDIR.get());

        // 5. Commands
        MinecraftForge.EVENT_BUS.addListener((RegisterCommandsEvent event) -> {
            DrinkOrDieGeneralCommands.register(event.getDispatcher());
            TemperatureCommand.register(event.getDispatcher());
        });

        LOGGER.info("Drink Or Die loaded!");
    }
}

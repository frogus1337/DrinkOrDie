package com.frogus.drinkordie.recipe;


import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.crafting.SpecialRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

import com.frogus.drinkordie.item.ModItems;

import com.frogus.drinkordie.item.ModItems;

public class CamelPackFillRecipe extends SpecialRecipe {

    public CamelPackFillRecipe(ResourceLocation id) {
        super(id);
    }

    @Override
    public boolean matches(CraftingContainer inv, Level level) {
        int camelPacks = 0;
        int waterBottles = 0;

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.getItem() == ModItems.CAMEL_PACK.get()) {
                camelPacks++;
            } else if (stack.getItem() == Items.WATER_BOTTLE) {
                waterBottles++;
            } else if (!stack.isEmpty()) {
                return false;
            }
        }
        return camelPacks == 1 && waterBottles >= 1 && waterBottles <= 4;
    }

    @Override
    public ItemStack assemble(CraftingContainer inv) {
        ItemStack camelPack = ItemStack.EMPTY;
        int waterBottles = 0;

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.getItem() == ModItems.CAMEL_PACK.get()) {
                camelPack = stack.copy();
            } else if (stack.getItem() == Items.WATER_BOTTLE) {
                waterBottles++;
            }
        }

        if (camelPack.isEmpty() || waterBottles == 0)
            return ItemStack.EMPTY;

        int amountPerBottle = 1000; // 1 Wasserflasche = 1000mB
        int maxWater = 4000;

        int currentWater = camelPack.getOrCreateTag().getInt("Water");
        int newWater = Math.min(currentWater + (waterBottles * amountPerBottle), maxWater);

        camelPack.getOrCreateTag().putInt("Water", newWater);
        return camelPack;
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipeSerializers.CAMEL_PACK_FILL.get();
    }
}

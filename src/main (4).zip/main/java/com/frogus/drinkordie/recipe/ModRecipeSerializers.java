package com.frogus.drinkordie.recipe;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.SpecialRecipeSerializer;

public class ModRecipeSerializers {
    public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS =
            DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, "drinkordie");

    public static final RegistryObject<RecipeSerializer<CamelPackFillRecipe>> CAMEL_PACK_FILL =
            RECIPE_SERIALIZERS.register("camel_pack_fill",
                    () -> new SpecialRecipeSerializer<>(CamelPackFillRecipe::new));
}
